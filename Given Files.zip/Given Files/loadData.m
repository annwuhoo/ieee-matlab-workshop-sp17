% This function loads data and returns it. Data is in the following form
% a b
% c d
% e f
% g h
% Load data into a matrix of size [2, inf] (means infinity columns allowed)
% and then transpose the matrix

function data = loadData(dataFile)
end
