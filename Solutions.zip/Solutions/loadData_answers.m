% This function loads data and returns it. Data is in the following form
% a b
% c d
% e f
% g h
% Load data into a matrix of size [2, inf] (means infinity columns allowed)
% and then transpose the matrix

function data = loadData_answers(dataFile)
    % answer: (if this is too hard, we can give this code to them)
    fid = fopen(dataFile, 'r');
    data = fscanf(fid, '%d', [2, inf])';
    fclose(fid);
end
